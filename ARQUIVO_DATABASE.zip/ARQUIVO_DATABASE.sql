-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           10.4.6-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              10.3.0.5771
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Copiando estrutura do banco de dados para softexpert
CREATE DATABASE IF NOT EXISTS `softexpert` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `softexpert`;

-- Copiando estrutura para tabela softexpert.produtos
CREATE TABLE IF NOT EXISTS `produtos` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL DEFAULT '',
  `descricao` varchar(500) NOT NULL DEFAULT '',
  `tipo` varchar(80) NOT NULL,
  `peso` float(5,2) NOT NULL,
  `preco` float(5,2) NOT NULL DEFAULT 0.00,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela softexpert.produtos: ~30 rows (aproximadamente)
/*!40000 ALTER TABLE `produtos` DISABLE KEYS */;
INSERT INTO `produtos` (`id`, `nome`, `descricao`, `tipo`, `peso`, `preco`, `create_at`) VALUES
	(1, 'San Juan Merlot', 'Medalha Commended no Decanter Wine World Awards, o rótulo San Juan reflete a festa das fogueiras da noite de San Juan na cidade de Toledo. Para elaborar este vinho extraímos a máxima expressão das uvas Merlot, Syrah e Tempranillo. Vinho de cor vermelho rubi escuro e brilhante.', 'Tinto', 1.00, 39.00, '2020-02-13 23:37:01'),
	(2, 'Adolfo Lona Brut Rosé', 'O premiado Adolfo Lona apresenta nesse espumante rosé uma mistura de aromas de frutas vermelhas como framboesa, morangos frescos e goiaba. Na boca, a elegância, o frescor e a limpidez impressionam a cada taça.', 'Espumante', 1.00, 54.00, '2020-02-13 23:47:06'),
	(3, 'Casanova Antaño Reserva Chardonnay', 'O Vinho Chardonnay Chileno Casanova Antaño Reserva, graças ao frescor conferido pela ausência de madeira, apresenta aromas de melão, pêssegos, baunilha e frutas secas. No palato, este branco é elegante e frutado. Final tostado e persistente.', 'Branco', 1.00, 29.00, '2020-02-13 23:49:08'),
	(4, 'Porto Ruby Maynard’s', 'Este Vinho do Porto Tawny da família Van Zeller demonstra a suavidade e o caráter frutado Portos. Em boca este Maynard\'s combina harmonicamente elegantes notas de frutas maduras, frutas secas e canela.', 'Doce', 1.00, 99.00, '2020-02-13 23:57:27'),
	(5, 'TROVATTI ROSSO IGT TERRE SICILIANE', 'Trovatti é um vinho que funde a elegância e sabor frutado da uva siciliana Nero d\'Avola com a riqueza e a força de duas variedades internacionais, Syrah e Merlot. No aspecto visual, o Trovatti exibe cor vermelha intensa. No olfativo mostra aromas ricos e perfumados, com notas de frutas vermelhas, como amora, framboesa e cereja, além de notas florais de violeta. No paladar é fresco, macio e suculento, com taninos sutis.', 'Tinto', 750.00, 0.00, '2020-02-15 01:09:19'),
	(6, 'DAIRO CRIANZA', 'Intensa com vermelho cereja. Aroma de frutas vermelhas e negras maduras envoltas em nuances de madeira, especiarias e minerais. Em boca o vinho apresenta boa estrutura, taninos macios, bom equilíbrio e elegância. Seu final é longo e saboroso.\r\n							', 'Tinto', 750.00, 122.00, '2020-02-15 01:18:05'),
	(7, 'CASTELO DE BORBA', 'De cor granada profunda, o vinho apresenta também aroma muito frutado, evidenciando aromas a compota e especiarias, um sabor macio, com volume, notas de frutos pretos muito maduros e taninos robustos, de longa persistência frutada.\r\n							', 'Tinto', 750.00, 110.00, '2020-02-15 01:39:38'),
	(8, 'Moinho de Sula Tinto', 'Vinho cor rubi vinificado com esmero a partir das castas típicas da região, apresenta-se macio, elegante e harmonioso que o tornam uma excelente companhia para as suas requintadas refeições do dia-a-dia. Seu aroma é predominante em frutos vermelhos e frutos do bosque bem maduros. Já seu sabor é frutado, macio, elegante com distinta persistência.\r\n							', 'Tinto', 750.00, 39.00, '2020-02-15 01:43:51'),
	(9, 'Escapada Casa Santos Lima', 'Elaborado com as uvas Castelão, Touriga Nacional, Syrah, Tinta Roriz e Alicante Bouschet, o Escapada Lisboa possui aromas de frutas vermelhas maduras. Na boca apresenta taninos redondos, notas de frutas negras, excelentes frescor e concentração.\r\n							', 'Tinto', 750.00, 72.00, '2020-02-15 01:46:13'),
	(10, 'CONDE DE MONTERROSO', 'Elaborado pela Bodegas Isidro Milagro, na região de La Mancha, o Vinho espanhol Conde de Moterroso Branco possui cor dourada brilhante com reflexos verdes. No nariz, apresenta um aroma poderoso e frutado, que faz referência a frutos da floresta. No paladar, é bastante equilibrado, redondo e com um bom final de boca.\r\n								', 'Branco', 750.00, 39.00, '2020-02-15 11:00:37'),
	(11, 'PORTAL DA VINHA RED', '\r\n				O vinho Portal da Vinha Red é jovem e intenso com as notas aromáticas de fruta vermelha bem presentes. Na boca revela boa estrutura e taninos suaves. Um tinto português com final harmonioso e agradável.				', 'Tinto', 750.00, 35.00, '2020-02-15 23:07:34'),
	(12, 'CHILENO VALDEMORO CABERNET SAUVIGNON', '\r\n			Vinho de cor rubi escuro brilhante. Aromas de frutos vermelho e negros frescos e com notas de baunilha e alcaçuz. Na boca saboroso, macio, tem corpo médio e equilibrada acidez que nos permite desfrutar de sua suavidade e persistência.					', 'Tinto', 750.00, 39.00, '2020-02-16 00:28:40'),
	(13, 'MONTEFRIO LA MANCHA D.O. TEMPRANILLO', '\r\n				O Vinho Montefrio é produzido em La Mancha, na Espanha, é um tinto agradável, que exibe profusas notas de frutos vermelhos e grande equilíbrio em boca. Esse Tinto Espanhol é descomplicado e fácil de beber. Excelente relação custo/benefício.				', 'Tinto', 750.00, 31.00, '2020-02-16 00:31:51'),
	(14, 'TEMPRANILLO SAN JUAN', '\r\n			O Vinho Rosé Espanhol San Juan apresenta cor rosado intenso e brilhante. Conserva os aromas de morangos e frutas vermelhos típicos da Tempranillo uva com a qual é elaborado. Em boca é equilibrado, persistente e tem um final limpo e persistente.					', 'Rosé', 750.00, 43.00, '2020-02-16 00:39:14'),
	(15, 'TEMPRANILLO SAN JUAN', '\r\n			O Vinho Rosé Espanhol San Juan apresenta cor rosado intenso e brilhante. Conserva os aromas de morangos e frutas vermelhos típicos da Tempranillo uva com a qual é elaborado. Em boca é equilibrado, persistente e tem um final limpo e persistente.					', 'Rosé', 750.00, 43.00, '2020-02-16 00:39:22'),
	(16, 'TEMPRANILLO SAN JUAN', '\r\n			O Vinho Rosé Espanhol San Juan apresenta cor rosado intenso e brilhante. Conserva os aromas de morangos e frutas vermelhos típicos da Tempranillo uva com a qual é elaborado. Em boca é equilibrado, persistente e tem um final limpo e persistente.					', 'Rosé', 750.00, 43.00, '2020-02-16 00:40:06'),
	(17, 'TEMPRANILLO SAN JUAN', '\r\n				O Vinho Rosé Espanhol San Juan apresenta cor rosado intenso e brilhante. Conserva os aromas de morangos e frutas vermelhos típicos da Tempranillo uva com a qual é elaborado. Em boca é equilibrado, persistente e tem um final limpo e persistente.				', 'Rosé', 750.00, 43.05, '2020-02-16 00:40:55'),
	(18, 'ESPANHOL ALCANTA MONASTRELL', 'O Alcanta Monastrell Rosé, um dos rótulos da Bodega Bocopa, em Alicante, na Espanha, é produzido com 100% de uvas Monastrell. É um vinho vintage que surpreende por sua frescura e leveza, resultando em um bebida muito agradável para se degustar e compartilhar à mesa todos os dias. De aromas deliciosos e nuances frutados, possui elegância e sabor pessoal.\r\n\r\n								', 'Rosé', 750.00, 55.00, '2020-02-16 00:46:35'),
	(19, 'ALCANTA MONASTRELL', '\r\n			O Alcanta Monastrell Rosé, um dos rótulos da Bodega Bocopa, em Alicante, na Espanha, é produzido com 100% de uvas Monastrell. É um vinho vintage que surpreende por sua frescura e leveza, resultando em um bebida muito agradável para se degustar e compartilhar à mesa todos os dias. De aromas deliciosos e nuances frutados, possui elegância e sabor pessoal.					', 'Rosé', 750.00, 5.00, '2020-02-16 00:47:17'),
	(20, 'ALCANTA MONASTRELL', '\r\n			O Alcanta Monastrell Rosé, um dos rótulos da Bodega Bocopa, em Alicante, na Espanha, é produzido com 100% de uvas Monastrell. É um vinho vintage que surpreende por sua frescura e leveza, resultando em um bebida muito agradável para se degustar e compartilhar à mesa todos os dias. De aromas deliciosos e nuances frutados, possui elegância e sabor pessoal.					', 'Rosé', 750.00, 5.00, '2020-02-16 00:50:37'),
	(21, 'ALCANTA MONASTRELL', '\r\n			O Alcanta Monastrell Rosé, um dos rótulos da Bodega Bocopa, em Alicante, na Espanha, é produzido com 100% de uvas Monastrell. É um vinho vintage que surpreende por sua frescura e leveza, resultando em um bebida muito agradável para se degustar e compartilhar à mesa todos os dias. De aromas deliciosos e nuances frutados, possui elegância e sabor pessoal.					', 'Rosé', 750.00, 5.00, '2020-02-16 00:50:49'),
	(22, 'ALCANTA MONASTRELL', '\r\n			O Alcanta Monastrell Rosé, um dos rótulos da Bodega Bocopa, em Alicante, na Espanha, é produzido com 100% de uvas Monastrell. É um vinho vintage que surpreende por sua frescura e leveza, resultando em um bebida muito agradável para se degustar e compartilhar à mesa todos os dias. De aromas deliciosos e nuances frutados, possui elegância e sabor pessoal.					', 'Rosé', 750.00, 5.00, '2020-02-16 00:51:01'),
	(23, 'ALCANTA MONASTRELL', '\r\n			O Alcanta Monastrell Rosé, um dos rótulos da Bodega Bocopa, em Alicante, na Espanha, é produzido com 100% de uvas Monastrell. É um vinho vintage que surpreende por sua frescura e leveza, resultando em um bebida muito agradável para se degustar e compartilhar à mesa todos os dias. De aromas deliciosos e nuances frutados, possui elegância e sabor pessoal.					', 'Rosé', 750.00, 5.00, '2020-02-16 00:51:31'),
	(24, 'RAMÉ SELECCIÓN', 'Um vinho jovem, de cor framboesa claro e brilhante produzido a partir do sumo de lágrima de uma selecção das melhores uvas Garnacha. Aroma intenso a frutos, suave e equilibrado e elegante.\r\n								', 'Rosé', 750.00, 450.00, '2020-02-16 00:52:22'),
	(25, 'FEUDO ARANCIO TINCHITÈ', 'O vinho demonstra a nobreza e riqueza de uma das videiras mais antigas da Sicilia. A uva Frappato apresenta um perfil de vinhos jovens com aromas florais e frutados. Além disso, o vinho apresenta cor de cereja quente, com distintas notas de rubi e violeta, um bouquet floral e fresco, com notas de gerânio e pequenas frutas como framboesa, amora, morango groselha, selvagem e romã, com sabor delicado, fresco e agradável.\r\n								', 'Rosé', 750.00, 950.00, '2020-02-16 00:53:18'),
	(26, 'Montefrio La Mancha D.O. ', 'O Vinho Montefrio Rosé, produzido em La Mancha, na Espanha, tem uma cor rosa característica. Esse vinho é leve, limpo, fresco e frutado. Ele mantém o sabor original dos morangos e das típicas frutas de variedade vermelha. Na boca, é equilibrado, refrescante e tem um longo acabamento limpo duradoura.\r\n								', 'Rosé', 750.00, 33.00, '2020-02-16 00:57:39'),
	(27, 'Montefrio La Mancha D.O. ', 'O Vinho Montefrio Rosé, produzido em La Mancha, na Espanha, tem uma cor rosa característica. Esse vinho é leve, limpo, fresco e frutado. Ele mantém o sabor original dos morangos e das típicas frutas de variedade vermelha. Na boca, é equilibrado, refrescante e tem um longo acabamento limpo duradoura.\r\n								', 'Rosé', 750.00, 33.00, '2020-02-16 00:58:31'),
	(28, 'Montefrio La Mancha D.O. ', 'O Vinho Montefrio Rosé, produzido em La Mancha, na Espanha, tem uma cor rosa característica. Esse vinho é leve, limpo, fresco e frutado. Ele mantém o sabor original dos morangos e das típicas frutas de variedade vermelha. Na boca, é equilibrado, refrescante e tem um longo acabamento limpo duradoura.\r\n								', 'Rosé', 750.00, 33.00, '2020-02-16 00:58:51'),
	(29, 'Montefrio La Mancha D.O. ', 'O Vinho Montefrio Rosé, produzido em La Mancha, na Espanha, tem uma cor rosa característica. Esse vinho é leve, limpo, fresco e frutado. Ele mantém o sabor original dos morangos e das típicas frutas de variedade vermelha. Na boca, é equilibrado, refrescante e tem um longo acabamento limpo duradoura.\r\n								', 'Rosé', 750.00, 999.99, '2020-02-16 01:00:55'),
	(30, 'Montefrio La Mancha D.O. ', 'O Vinho Montefrio Rosé, produzido em La Mancha, na Espanha, tem uma cor rosa característica. Esse vinho é leve, limpo, fresco e frutado. Ele mantém o sabor original dos morangos e das típicas frutas de variedade vermelha. Na boca, é equilibrado, refrescante e tem um longo acabamento limpo duradoura.\r\n								', 'Rosé', 750.00, 33.90, '2020-02-16 01:01:18');
/*!40000 ALTER TABLE `produtos` ENABLE KEYS */;

-- Copiando estrutura para tabela softexpert.vendas
CREATE TABLE IF NOT EXISTS `vendas` (
  `id_venda` int(11) NOT NULL AUTO_INCREMENT,
  `id_produto` int(11) unsigned DEFAULT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  `total` float(5,2) DEFAULT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_venda`),
  KEY `fk_id_produtos` (`id_produto`),
  CONSTRAINT `fk_id_produtos` FOREIGN KEY (`id_produto`) REFERENCES `produtos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela softexpert.vendas: ~12 rows (aproximadamente)
/*!40000 ALTER TABLE `vendas` DISABLE KEYS */;
INSERT INTO `vendas` (`id_venda`, `id_produto`, `nome`, `quantidade`, `total`, `create_at`) VALUES
	(1, 1, 'San Juan Merlot', NULL, 78.00, '2020-02-15 21:19:41'),
	(2, 1, 'San Juan Merlot', 2, 78.00, '2020-02-15 21:20:50'),
	(3, 1, 'San Juan Merlot', 2, 78.00, '2020-02-15 21:21:04'),
	(4, 1, 'San Juan Merlot', 2, 78.00, '2020-02-15 22:20:22'),
	(5, 1, 'San Juan Merlot', 3, 117.00, '2020-02-15 22:52:48'),
	(6, 1, 'San Juan Merlot', 2, 78.00, '2020-02-15 23:00:44'),
	(7, 1, 'San Juan Merlot', 4, 156.00, '2020-02-15 23:02:58'),
	(8, 2, 'Adolfo Lona Brut Rosé', 3, 162.00, '2020-02-15 23:04:59'),
	(9, 9, 'Escapada Casa Santos Lima', 4, 288.00, '2020-02-15 23:27:37'),
	(10, 8, 'Moinho de Sula Tinto', 5, 195.00, '2020-02-15 23:28:09'),
	(11, 10, 'CONDE DE MONTERROSO', 4, 156.00, '2020-02-15 23:31:55'),
	(12, 2, 'Adolfo Lona Brut Rosé', 3, 162.00, '2020-02-15 23:33:07'),
	(13, 17, 'TEMPRANILLO SAN JUAN', 4, 172.20, '2020-02-16 01:07:46');
/*!40000 ALTER TABLE `vendas` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
